#ifndef __MY_MATH_H_
	#define __MY_MATH_H_
	int MyAdd(int x, int y);
#endif
