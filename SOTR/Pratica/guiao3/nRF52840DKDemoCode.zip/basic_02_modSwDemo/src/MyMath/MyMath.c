#include "MyMath.h"

int MyAdd(int x, int y)
{
	return (x+y);
}
